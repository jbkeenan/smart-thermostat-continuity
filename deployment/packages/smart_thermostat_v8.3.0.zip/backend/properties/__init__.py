"""
Properties app for Smart Thermostat project.
This app handles property management functionality.
"""

default_app_config = 'properties.apps.PropertiesConfig'
