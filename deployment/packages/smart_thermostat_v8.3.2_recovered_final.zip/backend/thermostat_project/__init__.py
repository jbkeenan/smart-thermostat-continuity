# thermostat_project module initialization
