"""
Google Nest API Client
Handles communication with Google Nest thermostats via Device Access API
"""
import requests
import logging
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)


class NestClient:
    """Client for Google Nest thermostat API"""
    
    BASE_URL = "https://smartdevicemanagement.googleapis.com/v1"
    
    def __init__(self, device_id: str, access_token: str, refresh_token: str = None):
        self.device_id = device_id
        self.access_token = access_token
        self.refresh_token = refresh_token
        self.session = requests.Session()
        self.session.headers.update({
            'Authorization': f'Bearer {access_token}',
            'Content-Type': 'application/json'
        })
    
    def get_status(self) -> Dict[str, Any]:
        """Get current thermostat status"""
        try:
            url = f"{self.BASE_URL}/enterprises/project-id/devices/{self.device_id}"
            response = self.session.get(url)
            response.raise_for_status()
            
            data = response.json()
            traits = data.get('traits', {})
            
            # Extract temperature data
            temp_trait = traits.get('sdm.devices.traits.Temperature', {})
            humidity_trait = traits.get('sdm.devices.traits.Humidity', {})
            thermostat_trait = traits.get('sdm.devices.traits.ThermostatTemperatureSetpoint', {})
            hvac_trait = traits.get('sdm.devices.traits.ThermostatHvac', {})
            mode_trait = traits.get('sdm.devices.traits.ThermostatMode', {})
            
            # Convert Celsius to Fahrenheit
            current_temp_c = temp_trait.get('ambientTemperatureCelsius', 0)
            target_temp_c = thermostat_trait.get('heatCelsius') or thermostat_trait.get('coolCelsius', 0)
            
            current_temp_f = (current_temp_c * 9/5) + 32
            target_temp_f = (target_temp_c * 9/5) + 32
            
            return {
                'temperature': round(current_temp_f, 1),
                'target_temperature': round(target_temp_f, 1),
                'humidity': humidity_trait.get('ambientHumidityPercent'),
                'mode': mode_trait.get('mode', 'OFF').lower(),
                'is_heating': hvac_trait.get('status') == 'HEATING',
                'is_cooling': hvac_trait.get('status') == 'COOLING',
                'online': True
            }
            
        except requests.RequestException as e:
            logger.error(f"Error getting Nest status: {e}")
            raise Exception(f"Failed to get thermostat status: {e}")
    
    def set_temperature(self, temperature: float) -> Dict[str, Any]:
        """Set target temperature"""
        try:
            # Convert Fahrenheit to Celsius
            temp_celsius = (temperature - 32) * 5/9
            
            url = f"{self.BASE_URL}/enterprises/project-id/devices/{self.device_id}:executeCommand"
            
            # Determine if we're in heating or cooling mode
            current_status = self.get_status()
            mode = current_status.get('mode', 'heat')
            
            if mode in ['heat', 'auto']:
                command_data = {
                    "command": "sdm.devices.commands.ThermostatTemperatureSetpoint.SetHeat",
                    "params": {
                        "heatCelsius": temp_celsius
                    }
                }
            else:  # cool mode
                command_data = {
                    "command": "sdm.devices.commands.ThermostatTemperatureSetpoint.SetCool",
                    "params": {
                        "coolCelsius": temp_celsius
                    }
                }
            
            response = self.session.post(url, json=command_data)
            response.raise_for_status()
            
            return {"success": True, "temperature": temperature}
            
        except requests.RequestException as e:
            logger.error(f"Error setting Nest temperature: {e}")
            raise Exception(f"Failed to set temperature: {e}")
    
    def set_mode(self, mode: str) -> Dict[str, Any]:
        """Set thermostat mode"""
        try:
            # Map our modes to Nest modes
            mode_mapping = {
                'heat': 'HEAT',
                'cool': 'COOL',
                'auto': 'HEATCOOL',
                'off': 'OFF',
                'eco': 'ECO'
            }
            
            nest_mode = mode_mapping.get(mode.lower(), 'OFF')
            
            url = f"{self.BASE_URL}/enterprises/project-id/devices/{self.device_id}:executeCommand"
            command_data = {
                "command": "sdm.devices.commands.ThermostatMode.SetMode",
                "params": {
                    "mode": nest_mode
                }
            }
            
            response = self.session.post(url, json=command_data)
            response.raise_for_status()
            
            return {"success": True, "mode": mode}
            
        except requests.RequestException as e:
            logger.error(f"Error setting Nest mode: {e}")
            raise Exception(f"Failed to set mode: {e}")
    
    def set_fan_mode(self, fan_mode: str) -> Dict[str, Any]:
        """Set fan mode"""
        try:
            # Nest doesn't have direct fan control in the same way
            # This is a placeholder for fan control if available
            logger.info(f"Fan mode setting not directly supported for Nest: {fan_mode}")
            return {"success": True, "fan_mode": fan_mode, "note": "Fan mode not directly controllable"}
            
        except Exception as e:
            logger.error(f"Error setting Nest fan mode: {e}")
            raise Exception(f"Failed to set fan mode: {e}")
    
    def refresh_access_token(self) -> str:
        """Refresh the access token using refresh token"""
        if not self.refresh_token:
            raise Exception("No refresh token available")
        
        try:
            url = "https://oauth2.googleapis.com/token"
            data = {
                'client_id': 'your-client-id',  # Should be from environment
                'client_secret': 'your-client-secret',  # Should be from environment
                'refresh_token': self.refresh_token,
                'grant_type': 'refresh_token'
            }
            
            response = requests.post(url, data=data)
            response.raise_for_status()
            
            token_data = response.json()
            new_access_token = token_data['access_token']
            
            # Update session headers
            self.access_token = new_access_token
            self.session.headers.update({
                'Authorization': f'Bearer {new_access_token}'
            })
            
            return new_access_token
            
        except requests.RequestException as e:
            logger.error(f"Error refreshing Nest token: {e}")
            raise Exception(f"Failed to refresh access token: {e}")

