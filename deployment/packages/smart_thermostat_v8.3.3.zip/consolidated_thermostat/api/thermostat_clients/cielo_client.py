"""
Cielo API Client
Enhanced client using best practices for Cielo thermostat integration
"""
import requests
import logging
from typing import Dict, Any, Optional
import hashlib
import time

logger = logging.getLogger(__name__)


class CieloClient:
    """
    Enhanced Cielo API client with improved error handling and authentication
    Based on research of Cielo's actual API patterns
    """
    
    BASE_URL = "https://api.cielowigle.com/v1"
    
    def __init__(self, device_id: str, api_key: str = None, config: Dict = None):
        self.device_id = device_id
        self.api_key = api_key
        self.config = config or {}
        self.session = requests.Session()
        
        # Set up authentication headers
        if api_key:
            self.session.headers.update({
                'Authorization': f'Bearer {api_key}',
                'Content-Type': 'application/json',
                'User-Agent': 'SmartThermostat/1.0'
            })
        
        # Alternative authentication if using username/password
        self.username = self.config.get('username')
        self.password = self.config.get('password')
        self.auth_token = None
        
        if self.username and self.password:
            self._authenticate()
    
    def _authenticate(self) -> None:
        """Authenticate with Cielo using username/password"""
        try:
            auth_url = f"{self.BASE_URL}/auth/login"
            auth_data = {
                'username': self.username,
                'password': self.password
            }
            
            response = self.session.post(auth_url, json=auth_data)
            response.raise_for_status()
            
            auth_result = response.json()
            self.auth_token = auth_result.get('access_token')
            
            if self.auth_token:
                self.session.headers.update({
                    'Authorization': f'Bearer {self.auth_token}',
                    'Content-Type': 'application/json'
                })
                logger.info("Successfully authenticated with Cielo")
            
        except requests.RequestException as e:
            logger.error(f"Cielo authentication failed: {e}")
            raise Exception(f"Failed to authenticate with Cielo: {e}")
    
    def get_status(self) -> Dict[str, Any]:
        """Get current thermostat status"""
        try:
            url = f"{self.BASE_URL}/devices/{self.device_id}/status"
            response = self.session.get(url)
            response.raise_for_status()
            
            data = response.json()
            
            # Parse Cielo response format
            device_data = data.get('device', {})
            
            return {
                'temperature': device_data.get('current_temperature', 0),
                'target_temperature': device_data.get('target_temperature', 0),
                'humidity': device_data.get('humidity'),
                'mode': device_data.get('mode', 'off').lower(),
                'fan_mode': device_data.get('fan_speed', 'auto').lower(),
                'is_heating': device_data.get('heating_status', False),
                'is_cooling': device_data.get('cooling_status', False),
                'online': device_data.get('online', True)
            }
            
        except requests.RequestException as e:
            logger.error(f"Error getting Cielo status: {e}")
            raise Exception(f"Failed to get thermostat status: {e}")
    
    def set_temperature(self, temperature: float) -> Dict[str, Any]:
        """Set target temperature"""
        try:
            url = f"{self.BASE_URL}/devices/{self.device_id}/temperature"
            data = {
                'target_temperature': temperature,
                'unit': 'fahrenheit'
            }
            
            response = self.session.post(url, json=data)
            response.raise_for_status()
            
            return {"success": True, "temperature": temperature}
            
        except requests.RequestException as e:
            logger.error(f"Error setting Cielo temperature: {e}")
            raise Exception(f"Failed to set temperature: {e}")
    
    def set_mode(self, mode: str) -> Dict[str, Any]:
        """Set thermostat mode"""
        try:
            # Map our modes to Cielo modes
            mode_mapping = {
                'heat': 'heat',
                'cool': 'cool',
                'auto': 'auto',
                'off': 'off',
                'eco': 'eco'
            }
            
            cielo_mode = mode_mapping.get(mode.lower(), 'off')
            
            url = f"{self.BASE_URL}/devices/{self.device_id}/mode"
            data = {'mode': cielo_mode}
            
            response = self.session.post(url, json=data)
            response.raise_for_status()
            
            return {"success": True, "mode": mode}
            
        except requests.RequestException as e:
            logger.error(f"Error setting Cielo mode: {e}")
            raise Exception(f"Failed to set mode: {e}")
    
    def set_fan_mode(self, fan_mode: str) -> Dict[str, Any]:
        """Set fan mode"""
        try:
            # Map fan modes
            fan_mapping = {
                'auto': 'auto',
                'on': 'high',
                'circulate': 'medium'
            }
            
            cielo_fan = fan_mapping.get(fan_mode.lower(), 'auto')
            
            url = f"{self.BASE_URL}/devices/{self.device_id}/fan"
            data = {'fan_speed': cielo_fan}
            
            response = self.session.post(url, json=data)
            response.raise_for_status()
            
            return {"success": True, "fan_mode": fan_mode}
            
        except requests.RequestException as e:
            logger.error(f"Error setting Cielo fan mode: {e}")
            raise Exception(f"Failed to set fan mode: {e}")
    
    def set_schedule(self, schedule_data: Dict[str, Any]) -> Dict[str, Any]:
        """Set thermostat schedule"""
        try:
            url = f"{self.BASE_URL}/devices/{self.device_id}/schedule"
            
            response = self.session.post(url, json=schedule_data)
            response.raise_for_status()
            
            return {"success": True, "schedule": schedule_data}
            
        except requests.RequestException as e:
            logger.error(f"Error setting Cielo schedule: {e}")
            raise Exception(f"Failed to set schedule: {e}")
    
    def get_energy_data(self, days: int = 7) -> Dict[str, Any]:
        """Get energy consumption data"""
        try:
            url = f"{self.BASE_URL}/devices/{self.device_id}/energy"
            params = {'days': days}
            
            response = self.session.get(url, params=params)
            response.raise_for_status()
            
            return response.json()
            
        except requests.RequestException as e:
            logger.error(f"Error getting Cielo energy data: {e}")
            raise Exception(f"Failed to get energy data: {e}")


class CieloHomeClient:
    """
    Alternative Cielo client using the bodyscape/cielo_home library approach
    This would be used if we integrate the community library
    """
    
    def __init__(self, username: str, password: str):
        self.username = username
        self.password = password
        # This would use the actual cielo_home library if installed
        # from cielo_home import CieloHome
        # self.client = CieloHome(username, password)
    
    def get_devices(self):
        """Get list of Cielo devices"""
        # Implementation would use cielo_home library
        pass
    
    def control_device(self, device_id: str, **kwargs):
        """Control Cielo device using community library"""
        # Implementation would use cielo_home library
        pass

