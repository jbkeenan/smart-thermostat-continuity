from rest_framework import viewsets, status, permissions
from rest_framework.decorators import action, api_view, permission_classes
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework_simplejwt.views import TokenObtainPairView
from django.contrib.auth import get_user_model
from django.db.models import Count, Q, Avg, Sum
from django.utils import timezone
from datetime import datetime, timedelta
import logging

from .serializers import (
    UserSerializer, PropertySerializer, PropertySettingsSerializer,
    PropertyScheduleSerializer, ThermostatSerializer, ThermostatCommandSerializer,
    ThermostatReadingSerializer, ThermostatAlertSerializer, ThermostatControlSerializer,
    DashboardSerializer, AnalyticsSerializer, PropertyEnergyDataSerializer
)
from properties.models import Property, PropertySettings, PropertySchedule, PropertyEnergyData
from thermostats.models import Thermostat, ThermostatCommand, ThermostatReading, ThermostatAlert
from .thermostat_clients.nest_client import NestClient
from .thermostat_clients.cielo_client import CieloClient

User = get_user_model()
logger = logging.getLogger(__name__)


class CustomTokenObtainPairView(TokenObtainPairView):
    """Custom JWT token view with user data"""
    
    def post(self, request, *args, **kwargs):
        response = super().post(request, *args, **kwargs)
        if response.status_code == 200:
            user = User.objects.get(email=request.data['email'])
            response.data['user'] = UserSerializer(user).data
        return response


@api_view(['POST'])
@permission_classes([AllowAny])
def register(request):
    """User registration endpoint"""
    serializer = UserSerializer(data=request.data)
    if serializer.is_valid():
        user = serializer.save()
        return Response({
            'message': 'User created successfully',
            'user': UserSerializer(user).data
        }, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class PropertyViewSet(viewsets.ModelViewSet):
    """ViewSet for managing properties"""
    serializer_class = PropertySerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        return Property.objects.filter(owner=self.request.user).prefetch_related(
            'thermostats', 'schedules', 'settings'
        )
    
    def perform_create(self, serializer):
        serializer.save(owner=self.request.user)
    
    @action(detail=True, methods=['get'])
    def dashboard(self, request, pk=None):
        """Get dashboard data for a specific property"""
        property_obj = self.get_object()
        
        # Get recent alerts
        recent_alerts = ThermostatAlert.objects.filter(
            thermostat__property_ref=property_obj,
            is_active=True
        ).order_by('-created_at')[:5]
        
        # Calculate energy summary
        today = timezone.now().date()
        week_ago = today - timedelta(days=7)
        
        energy_data = PropertyEnergyData.objects.filter(
            property_ref=property_obj,
            date__gte=week_ago
        ).aggregate(
            total_energy=Sum('energy_consumed'),
            total_cost=Sum('cost'),
            avg_temperature=Avg('average_indoor_temperature')
        )
        
        dashboard_data = {
            'total_thermostats': property_obj.thermostats.count(),
            'online_thermostats': property_obj.thermostats.filter(is_online=True).count(),
            'active_schedules': property_obj.schedules.filter(is_active=True).count(),
            'recent_alerts': ThermostatAlertSerializer(recent_alerts, many=True).data,
            'energy_summary': energy_data
        }
        
        return Response(dashboard_data)
    
    @action(detail=True, methods=['get'])
    def analytics(self, request, pk=None):
        """Get analytics data for a property"""
        property_obj = self.get_object()
        days = int(request.query_params.get('days', 30))
        start_date = timezone.now().date() - timedelta(days=days)
        
        # Energy usage trend
        energy_trend = PropertyEnergyData.objects.filter(
            property_ref=property_obj,
            date__gte=start_date
        ).values('date').annotate(
            total_energy=Sum('energy_consumed'),
            total_cost=Sum('cost')
        ).order_by('date')
        
        # Temperature trends from thermostat readings
        temp_trend = ThermostatReading.objects.filter(
            thermostat__property_ref=property_obj,
            timestamp__date__gte=start_date
        ).extra(
            select={'date': 'DATE(timestamp)'}
        ).values('date').annotate(
            avg_temp=Avg('temperature'),
            avg_target=Avg('target_temperature')
        ).order_by('date')
        
        analytics_data = {
            'energy_usage_trend': list(energy_trend),
            'temperature_trends': list(temp_trend),
            'cost_savings': {'monthly_savings': 0, 'yearly_projection': 0},
            'efficiency_metrics': {'avg_efficiency': 85, 'optimization_score': 92}
        }
        
        return Response(analytics_data)


class ThermostatViewSet(viewsets.ModelViewSet):
    """ViewSet for managing thermostats"""
    serializer_class = ThermostatSerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        return Thermostat.objects.filter(
            property_ref__owner=self.request.user
        ).select_related('property_ref')
    
    @action(detail=True, methods=['post'])
    def control(self, request, pk=None):
        """Control thermostat (set temperature, mode, etc.)"""
        thermostat = self.get_object()
        serializer = ThermostatControlSerializer(data=request.data)
        
        if serializer.is_valid():
            try:
                # Get the appropriate client for this thermostat
                client = self._get_thermostat_client(thermostat)
                
                action = serializer.validated_data['action']
                result = None
                
                if action == 'set_temperature':
                    temperature = serializer.validated_data['temperature']
                    result = client.set_temperature(float(temperature))
                    thermostat.target_temperature = temperature
                
                elif action == 'set_mode':
                    mode = serializer.validated_data['mode']
                    result = client.set_mode(mode)
                    thermostat.mode = mode
                
                elif action == 'set_fan_mode':
                    fan_mode = serializer.validated_data['fan_mode']
                    result = client.set_fan_mode(fan_mode)
                    thermostat.fan_mode = fan_mode
                
                # Save thermostat state
                thermostat.save()
                
                # Log the command
                ThermostatCommand.objects.create(
                    thermostat=thermostat,
                    command_type=action,
                    parameters=serializer.validated_data,
                    status='success' if result else 'failed',
                    result=result,
                    initiated_by=request.user,
                    source='manual'
                )
                
                return Response({
                    'message': 'Command sent successfully',
                    'result': result
                })
                
            except Exception as e:
                logger.error(f"Error controlling thermostat {thermostat.id}: {str(e)}")
                
                # Log failed command
                ThermostatCommand.objects.create(
                    thermostat=thermostat,
                    command_type=action,
                    parameters=serializer.validated_data,
                    status='failed',
                    error_message=str(e),
                    initiated_by=request.user,
                    source='manual'
                )
                
                return Response({
                    'error': 'Failed to control thermostat',
                    'details': str(e)
                }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    @action(detail=True, methods=['post'])
    def sync(self, request, pk=None):
        """Sync thermostat status with device"""
        thermostat = self.get_object()
        
        try:
            client = self._get_thermostat_client(thermostat)
            device_status = client.get_status()
            
            # Update thermostat with current status
            thermostat.current_temperature = device_status.get('temperature')
            thermostat.target_temperature = device_status.get('target_temperature')
            thermostat.current_humidity = device_status.get('humidity')
            thermostat.mode = device_status.get('mode', thermostat.mode)
            thermostat.fan_mode = device_status.get('fan_mode', thermostat.fan_mode)
            thermostat.is_heating = device_status.get('is_heating', False)
            thermostat.is_cooling = device_status.get('is_cooling', False)
            thermostat.is_online = True
            thermostat.last_seen = timezone.now()
            thermostat.save()
            
            # Create reading record
            ThermostatReading.objects.create(
                thermostat=thermostat,
                temperature=device_status.get('temperature', 0),
                humidity=device_status.get('humidity'),
                target_temperature=device_status.get('target_temperature', 0),
                mode=device_status.get('mode', 'off'),
                fan_mode=device_status.get('fan_mode', 'auto'),
                is_heating=device_status.get('is_heating', False),
                is_cooling=device_status.get('is_cooling', False),
                timestamp=timezone.now()
            )
            
            return Response({
                'message': 'Thermostat synced successfully',
                'status': device_status
            })
            
        except Exception as e:
            logger.error(f"Error syncing thermostat {thermostat.id}: {str(e)}")
            thermostat.is_online = False
            thermostat.save()
            
            return Response({
                'error': 'Failed to sync thermostat',
                'details': str(e)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    def _get_thermostat_client(self, thermostat):
        """Get the appropriate API client for the thermostat brand"""
        if thermostat.brand == 'nest':
            return NestClient(
                device_id=thermostat.device_id,
                access_token=thermostat.api_token,
                refresh_token=thermostat.api_refresh_token
            )
        elif thermostat.brand == 'cielo':
            return CieloClient(
                device_id=thermostat.device_id,
                api_key=thermostat.api_key,
                config=thermostat.api_config
            )
        else:
            raise ValueError(f"Unsupported thermostat brand: {thermostat.brand}")


class PropertyScheduleViewSet(viewsets.ModelViewSet):
    """ViewSet for managing property schedules"""
    serializer_class = PropertyScheduleSerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        return PropertySchedule.objects.filter(
            property_ref__owner=self.request.user
        ).select_related('property_ref')


class ThermostatReadingViewSet(viewsets.ReadOnlyModelViewSet):
    """ViewSet for thermostat readings (read-only)"""
    serializer_class = ThermostatReadingSerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        return ThermostatReading.objects.filter(
            thermostat__property_ref__owner=self.request.user
        ).select_related('thermostat')


class ThermostatAlertViewSet(viewsets.ModelViewSet):
    """ViewSet for thermostat alerts"""
    serializer_class = ThermostatAlertSerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        return ThermostatAlert.objects.filter(
            thermostat__property_ref__owner=self.request.user
        ).select_related('thermostat')
    
    @action(detail=True, methods=['post'])
    def acknowledge(self, request, pk=None):
        """Acknowledge an alert"""
        alert = self.get_object()
        alert.is_acknowledged = True
        alert.acknowledged_by = request.user
        alert.acknowledged_at = timezone.now()
        alert.save()
        
        return Response({'message': 'Alert acknowledged'})


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def dashboard(request):
    """Global dashboard for all user properties"""
    user_properties = Property.objects.filter(owner=request.user)
    
    # Aggregate statistics
    total_thermostats = Thermostat.objects.filter(
        property_ref__owner=request.user
    ).count()
    
    online_thermostats = Thermostat.objects.filter(
        property_ref__owner=request.user,
        is_online=True
    ).count()
    
    active_schedules = PropertySchedule.objects.filter(
        property_ref__owner=request.user,
        is_active=True
    ).count()
    
    # Recent alerts across all properties
    recent_alerts = ThermostatAlert.objects.filter(
        thermostat__property_ref__owner=request.user,
        is_active=True
    ).order_by('-created_at')[:10]
    
    # Energy summary across all properties
    today = timezone.now().date()
    week_ago = today - timedelta(days=7)
    
    energy_summary = PropertyEnergyData.objects.filter(
        property_ref__owner=request.user,
        date__gte=week_ago
    ).aggregate(
        total_energy=Sum('energy_consumed'),
        total_cost=Sum('cost'),
        avg_temperature=Avg('average_indoor_temperature')
    )
    
    dashboard_data = {
        'total_properties': user_properties.count(),
        'total_thermostats': total_thermostats,
        'online_thermostats': online_thermostats,
        'active_schedules': active_schedules,
        'recent_alerts': ThermostatAlertSerializer(recent_alerts, many=True).data,
        'energy_summary': energy_summary or {}
    }
    
    return Response(dashboard_data)

