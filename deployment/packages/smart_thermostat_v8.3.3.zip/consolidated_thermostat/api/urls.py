from django.urls import path, include
from rest_framework.routers import DefaultRouter
from rest_framework_simplejwt.views import TokenRefreshView
from . import views

# Create router for ViewSets
router = DefaultRouter()
router.register(r'properties', views.PropertyViewSet, basename='property')
router.register(r'thermostats', views.ThermostatViewSet, basename='thermostat')
router.register(r'schedules', views.PropertyScheduleViewSet, basename='schedule')
router.register(r'readings', views.ThermostatReadingViewSet, basename='reading')
router.register(r'alerts', views.ThermostatAlertViewSet, basename='alert')

urlpatterns = [
    # Authentication endpoints
    path('auth/login/', views.CustomTokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('auth/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('auth/register/', views.register, name='register'),
    
    # Dashboard endpoint
    path('dashboard/', views.dashboard, name='dashboard'),
    
    # Include router URLs
    path('', include(router.urls)),
]

