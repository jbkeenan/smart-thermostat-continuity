from rest_framework import serializers
from django.contrib.auth import get_user_model
from properties.models import Property, PropertySettings, PropertySchedule, PropertyEnergyData
from thermostats.models import Thermostat, ThermostatCommand, ThermostatReading, ThermostatAlert

User = get_user_model()


class UserSerializer(serializers.ModelSerializer):
    """Serializer for user registration and profile"""
    password = serializers.CharField(write_only=True)
    password_confirm = serializers.CharField(write_only=True)
    
    class Meta:
        model = User
        fields = ('id', 'username', 'email', 'first_name', 'last_name', 
                 'phone_number', 'preferred_temperature_unit', 'password', 'password_confirm')
        extra_kwargs = {
            'password': {'write_only': True},
            'password_confirm': {'write_only': True},
        }
    
    def validate(self, attrs):
        if attrs['password'] != attrs['password_confirm']:
            raise serializers.ValidationError("Passwords don't match")
        return attrs
    
    def create(self, validated_data):
        validated_data.pop('password_confirm')
        password = validated_data.pop('password')
        user = User.objects.create_user(**validated_data)
        user.set_password(password)
        user.save()
        return user


class PropertySettingsSerializer(serializers.ModelSerializer):
    """Serializer for property settings"""
    class Meta:
        model = PropertySettings
        fields = '__all__'


class PropertyScheduleSerializer(serializers.ModelSerializer):
    """Serializer for property schedules"""
    is_currently_active = serializers.ReadOnlyField()
    
    class Meta:
        model = PropertySchedule
        fields = '__all__'


class ThermostatSerializer(serializers.ModelSerializer):
    """Serializer for thermostats"""
    display_name = serializers.ReadOnlyField()
    is_connected = serializers.ReadOnlyField()
    
    class Meta:
        model = Thermostat
        fields = '__all__'
        extra_kwargs = {
            'api_key': {'write_only': True},
            'api_token': {'write_only': True},
            'api_refresh_token': {'write_only': True},
        }


class PropertySerializer(serializers.ModelSerializer):
    """Serializer for properties with nested data"""
    settings = PropertySettingsSerializer(read_only=True)
    thermostats = ThermostatSerializer(many=True, read_only=True)
    schedules = PropertyScheduleSerializer(many=True, read_only=True)
    thermostat_count = serializers.ReadOnlyField()
    active_schedules_count = serializers.ReadOnlyField()
    
    class Meta:
        model = Property
        fields = '__all__'
    
    def create(self, validated_data):
        # Automatically create property settings when property is created
        property_instance = super().create(validated_data)
        PropertySettings.objects.create(property_ref=property_instance)
        return property_instance


class PropertyEnergyDataSerializer(serializers.ModelSerializer):
    """Serializer for property energy data"""
    class Meta:
        model = PropertyEnergyData
        fields = '__all__'


class ThermostatCommandSerializer(serializers.ModelSerializer):
    """Serializer for thermostat commands"""
    class Meta:
        model = ThermostatCommand
        fields = '__all__'


class ThermostatReadingSerializer(serializers.ModelSerializer):
    """Serializer for thermostat readings"""
    class Meta:
        model = ThermostatReading
        fields = '__all__'


class ThermostatAlertSerializer(serializers.ModelSerializer):
    """Serializer for thermostat alerts"""
    class Meta:
        model = ThermostatAlert
        fields = '__all__'


class ThermostatControlSerializer(serializers.Serializer):
    """Serializer for thermostat control commands"""
    action = serializers.ChoiceField(choices=[
        ('set_temperature', 'Set Temperature'),
        ('set_mode', 'Set Mode'),
        ('set_fan_mode', 'Set Fan Mode'),
    ])
    temperature = serializers.DecimalField(max_digits=4, decimal_places=1, required=False)
    mode = serializers.ChoiceField(
        choices=Thermostat.THERMOSTAT_MODES, 
        required=False
    )
    fan_mode = serializers.ChoiceField(
        choices=Thermostat.FAN_MODES, 
        required=False
    )
    
    def validate(self, attrs):
        action = attrs.get('action')
        
        if action == 'set_temperature' and 'temperature' not in attrs:
            raise serializers.ValidationError("Temperature is required for set_temperature action")
        
        if action == 'set_mode' and 'mode' not in attrs:
            raise serializers.ValidationError("Mode is required for set_mode action")
        
        if action == 'set_fan_mode' and 'fan_mode' not in attrs:
            raise serializers.ValidationError("Fan mode is required for set_fan_mode action")
        
        return attrs


class DashboardSerializer(serializers.Serializer):
    """Serializer for dashboard data"""
    total_properties = serializers.IntegerField()
    total_thermostats = serializers.IntegerField()
    online_thermostats = serializers.IntegerField()
    active_schedules = serializers.IntegerField()
    recent_alerts = ThermostatAlertSerializer(many=True)
    energy_summary = serializers.DictField()


class AnalyticsSerializer(serializers.Serializer):
    """Serializer for analytics data"""
    energy_usage_trend = serializers.ListField()
    temperature_trends = serializers.ListField()
    cost_savings = serializers.DictField()
    efficiency_metrics = serializers.DictField()

