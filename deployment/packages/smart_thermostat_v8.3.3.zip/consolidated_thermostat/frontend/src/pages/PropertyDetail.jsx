import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  ArrowLeft,
  Thermometer, 
  Calendar,
  TrendingUp,
  Settings,
  Plus,
  MapPin,
  Home
} from 'lucide-react';
import { apiClient } from '../utils/api';
import ThermostatCard from '../components/thermostat/ThermostatCard';

const PropertyDetail = () => {
  const { id } = useParams();
  const [property, setProperty] = useState(null);
  const [dashboardData, setDashboardData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (id) {
      fetchPropertyData();
    }
  }, [id]);

  const fetchPropertyData = async () => {
    try {
      const [propertyData, dashboard] = await Promise.all([
        apiClient.getProperty(id),
        apiClient.getPropertyDashboard(id)
      ]);
      setProperty(propertyData);
      setDashboardData(dashboard);
    } catch (error) {
      setError('Failed to load property data');
      console.error('Property detail error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="sm" disabled>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div className="h-8 bg-gray-200 rounded w-48 animate-pulse"></div>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <Card className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-32 bg-gray-200 rounded"></div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  if (error || !property) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="sm" asChild>
            <Link to="/properties">
              <ArrowLeft className="h-4 w-4" />
            </Link>
          </Button>
          <h1 className="text-3xl font-bold">Property Details</h1>
        </div>
        <Alert variant="destructive">
          <AlertDescription>{error || 'Property not found'}</AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="sm" asChild>
          <Link to="/properties">
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>
        <div className="flex-1">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            {property.name}
          </h1>
          <p className="text-gray-600 dark:text-gray-400 flex items-center gap-1">
            <MapPin className="h-4 w-4" />
            {property.address}
          </p>
        </div>
        <Button asChild>
          <Link to={`/properties/${property.id}/edit`}>
            <Settings className="mr-2 h-4 w-4" />
            Settings
          </Link>
        </Button>
      </div>

      {/* Property Info Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Home className="h-5 w-5" />
            Property Information
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <h4 className="font-semibold text-gray-900 dark:text-white mb-2">Type</h4>
              <Badge variant="secondary">{property.property_type}</Badge>
            </div>
            <div>
              <h4 className="font-semibold text-gray-900 dark:text-white mb-2">Size</h4>
              <p className="text-gray-600 dark:text-gray-400">
                {property.square_footage ? `${property.square_footage} sq ft` : 'Not specified'}
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-gray-900 dark:text-white mb-2">Status</h4>
              <Badge variant={property.is_primary ? 'default' : 'secondary'}>
                {property.is_primary ? 'Primary' : 'Secondary'}
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tabs */}
      <Tabs defaultValue="thermostats" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="thermostats">Thermostats</TabsTrigger>
          <TabsTrigger value="schedules">Schedules</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="thermostats" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">Thermostats</h2>
            <Button asChild>
              <Link to={`/properties/${property.id}/thermostats/new`}>
                <Plus className="mr-2 h-4 w-4" />
                Add Thermostat
              </Link>
            </Button>
          </div>

          {property.thermostats && property.thermostats.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {property.thermostats.map((thermostat) => (
                <ThermostatCard key={thermostat.id} thermostat={thermostat} />
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="p-12 text-center">
                <Thermometer className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  No thermostats yet
                </h3>
                <p className="text-gray-600 dark:text-gray-400 mb-6">
                  Add thermostats to start controlling the temperature in this property.
                </p>
                <Button asChild>
                  <Link to={`/properties/${property.id}/thermostats/new`}>
                    <Plus className="mr-2 h-4 w-4" />
                    Add First Thermostat
                  </Link>
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="schedules" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">Schedules</h2>
            <Button asChild>
              <Link to={`/properties/${property.id}/schedules/new`}>
                <Plus className="mr-2 h-4 w-4" />
                Add Schedule
              </Link>
            </Button>
          </div>

          {property.schedules && property.schedules.length > 0 ? (
            <div className="space-y-4">
              {property.schedules.map((schedule) => (
                <Card key={schedule.id}>
                  <CardContent className="p-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <h4 className="font-semibold">{schedule.name}</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          {schedule.start_time} - {schedule.end_time}
                        </p>
                      </div>
                      <Badge variant={schedule.is_active ? 'default' : 'secondary'}>
                        {schedule.is_active ? 'Active' : 'Inactive'}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="p-12 text-center">
                <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  No schedules yet
                </h3>
                <p className="text-gray-600 dark:text-gray-400 mb-6">
                  Create schedules to automatically control your thermostats.
                </p>
                <Button asChild>
                  <Link to={`/properties/${property.id}/schedules/new`}>
                    <Plus className="mr-2 h-4 w-4" />
                    Create First Schedule
                  </Link>
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          <h2 className="text-xl font-semibold">Analytics</h2>
          
          {dashboardData ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Energy Usage</CardTitle>
                  <CardDescription>Last 7 days</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Total Energy</span>
                      <span className="font-semibold">
                        {dashboardData.energy_summary?.total_energy?.toFixed(2) || '0.00'} kWh
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Total Cost</span>
                      <span className="font-semibold">
                        ${dashboardData.energy_summary?.total_cost?.toFixed(2) || '0.00'}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Temperature</CardTitle>
                  <CardDescription>Average indoor temperature</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">
                    {dashboardData.energy_summary?.avg_temperature?.toFixed(1) || '0.0'}°F
                  </div>
                </CardContent>
              </Card>
            </div>
          ) : (
            <Card>
              <CardContent className="p-12 text-center">
                <TrendingUp className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  No analytics data yet
                </h3>
                <p className="text-gray-600 dark:text-gray-400">
                  Analytics will appear once you have thermostats collecting data.
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default PropertyDetail;

