import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { 
  Thermometer, 
  Power, 
  Snowflake, 
  Sun, 
  Wind,
  Settings,
  Wifi,
  WifiOff
} from 'lucide-react';
import { apiClient } from '../../utils/api';

const ThermostatCard = ({ thermostat, onUpdate }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [currentTemp, setCurrentTemp] = useState(thermostat.current_temperature || 70);
  const [targetTemp, setTargetTemp] = useState(thermostat.target_temperature || 72);
  const [mode, setMode] = useState(thermostat.mode || 'auto');
  const [isOn, setIsOn] = useState(thermostat.is_on || false);

  const handleTemperatureChange = async (newTemp) => {
    setTargetTemp(newTemp[0]);
    await controlThermostat('set_temperature', { temperature: newTemp[0] });
  };

  const handleModeChange = async (newMode) => {
    setMode(newMode);
    await controlThermostat('set_mode', { mode: newMode });
  };

  const handlePowerToggle = async () => {
    const newState = !isOn;
    setIsOn(newState);
    await controlThermostat('set_power', { power: newState });
  };

  const controlThermostat = async (action, params) => {
    setIsLoading(true);
    try {
      const result = await apiClient.controlThermostat(thermostat.id, action, params);
      if (onUpdate) {
        onUpdate(result);
      }
    } catch (error) {
      console.error('Thermostat control error:', error);
      // Revert changes on error
      if (action === 'set_temperature') {
        setTargetTemp(thermostat.target_temperature);
      } else if (action === 'set_mode') {
        setMode(thermostat.mode);
      } else if (action === 'set_power') {
        setIsOn(thermostat.is_on);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const getModeIcon = (mode) => {
    switch (mode) {
      case 'heat':
        return <Sun className="h-4 w-4" />;
      case 'cool':
        return <Snowflake className="h-4 w-4" />;
      case 'fan':
        return <Wind className="h-4 w-4" />;
      default:
        return <Thermometer className="h-4 w-4" />;
    }
  };

  const getModeColor = (mode) => {
    switch (mode) {
      case 'heat':
        return 'text-orange-600 bg-orange-100';
      case 'cool':
        return 'text-blue-600 bg-blue-100';
      case 'fan':
        return 'text-gray-600 bg-gray-100';
      default:
        return 'text-green-600 bg-green-100';
    }
  };

  return (
    <Card className={`transition-all duration-200 ${isLoading ? 'opacity-50' : ''}`}>
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-lg flex items-center gap-2">
              <Thermometer className="h-5 w-5" />
              {thermostat.name}
            </CardTitle>
            <CardDescription>
              {thermostat.location} • {thermostat.brand}
            </CardDescription>
          </div>
          <div className="flex items-center gap-2">
            {thermostat.is_online ? (
              <Wifi className="h-4 w-4 text-green-600" />
            ) : (
              <WifiOff className="h-4 w-4 text-red-600" />
            )}
            <Badge variant={thermostat.is_online ? 'default' : 'secondary'}>
              {thermostat.is_online ? 'Online' : 'Offline'}
            </Badge>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Power Toggle */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Power className="h-4 w-4" />
            <span className="font-medium">Power</span>
          </div>
          <Switch
            checked={isOn}
            onCheckedChange={handlePowerToggle}
            disabled={isLoading || !thermostat.is_online}
          />
        </div>

        {/* Current Temperature Display */}
        <div className="text-center py-4">
          <div className="text-4xl font-bold text-gray-900 dark:text-white">
            {currentTemp}°F
          </div>
          <p className="text-sm text-gray-600 dark:text-gray-400">
            Current Temperature
          </p>
        </div>

        {/* Target Temperature Slider */}
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <span className="font-medium">Target Temperature</span>
            <span className="text-lg font-semibold">{targetTemp}°F</span>
          </div>
          <Slider
            value={[targetTemp]}
            onValueChange={handleTemperatureChange}
            min={50}
            max={90}
            step={1}
            disabled={isLoading || !thermostat.is_online || !isOn}
            className="w-full"
          />
        </div>

        {/* Mode Selection */}
        <div className="space-y-3">
          <span className="font-medium">Mode</span>
          <div className="grid grid-cols-4 gap-2">
            {['auto', 'heat', 'cool', 'fan'].map((modeOption) => (
              <Button
                key={modeOption}
                variant={mode === modeOption ? 'default' : 'outline'}
                size="sm"
                onClick={() => handleModeChange(modeOption)}
                disabled={isLoading || !thermostat.is_online || !isOn}
                className={`flex flex-col items-center gap-1 h-auto py-2 ${
                  mode === modeOption ? getModeColor(modeOption) : ''
                }`}
              >
                {getModeIcon(modeOption)}
                <span className="text-xs capitalize">{modeOption}</span>
              </Button>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="flex gap-2 pt-2">
          <Button 
            variant="outline" 
            size="sm" 
            className="flex-1"
            onClick={() => handleTemperatureChange([targetTemp - 2])}
            disabled={isLoading || !thermostat.is_online || !isOn || targetTemp <= 50}
          >
            -2°F
          </Button>
          <Button 
            variant="outline" 
            size="sm" 
            className="flex-1"
            onClick={() => handleTemperatureChange([targetTemp + 2])}
            disabled={isLoading || !thermostat.is_online || !isOn || targetTemp >= 90}
          >
            +2°F
          </Button>
          <Button variant="outline" size="sm">
            <Settings className="h-4 w-4" />
          </Button>
        </div>

        {/* Status Info */}
        <div className="text-xs text-gray-500 dark:text-gray-400 space-y-1">
          <div className="flex justify-between">
            <span>Last Updated:</span>
            <span>{new Date(thermostat.last_updated).toLocaleTimeString()}</span>
          </div>
          {thermostat.energy_usage && (
            <div className="flex justify-between">
              <span>Energy Usage:</span>
              <span>{thermostat.energy_usage.toFixed(2)} kWh</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default ThermostatCard;

