import { useAuth } from '../contexts/AuthContext';

const API_BASE_URL = '/api';

class ApiClient {
  constructor() {
    this.baseURL = API_BASE_URL;
  }

  async request(endpoint, options = {}) {
    const url = `${this.baseURL}${endpoint}`;
    const token = localStorage.getItem('token');
    
    const config = {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    };

    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }

    try {
      const response = await fetch(url, config);
      
      if (response.status === 401) {
        // Token expired, try to refresh
        const refreshed = await this.refreshToken();
        if (refreshed) {
          // Retry the original request
          config.headers.Authorization = `Bearer ${localStorage.getItem('token')}`;
          return await fetch(url, config);
        } else {
          // Refresh failed, redirect to login
          window.location.href = '/login';
          return;
        }
      }

      return response;
    } catch (error) {
      console.error('API request failed:', error);
      throw error;
    }
  }

  async refreshToken() {
    const refresh = localStorage.getItem('refreshToken');
    if (!refresh) return false;

    try {
      const response = await fetch(`${this.baseURL}/auth/refresh/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ refresh }),
      });

      if (response.ok) {
        const data = await response.json();
        localStorage.setItem('token', data.access);
        return true;
      }
    } catch (error) {
      console.error('Token refresh failed:', error);
    }

    return false;
  }

  // Properties
  async getProperties() {
    const response = await this.request('/properties/');
    return response.json();
  }

  async getProperty(id) {
    const response = await this.request(`/properties/${id}/`);
    return response.json();
  }

  async createProperty(data) {
    const response = await this.request('/properties/', {
      method: 'POST',
      body: JSON.stringify(data),
    });
    return response.json();
  }

  async updateProperty(id, data) {
    const response = await this.request(`/properties/${id}/`, {
      method: 'PATCH',
      body: JSON.stringify(data),
    });
    return response.json();
  }

  async deleteProperty(id) {
    const response = await this.request(`/properties/${id}/`, {
      method: 'DELETE',
    });
    return response.ok;
  }

  async getPropertyDashboard(id) {
    const response = await this.request(`/properties/${id}/dashboard/`);
    return response.json();
  }

  async getPropertyAnalytics(id, days = 30) {
    const response = await this.request(`/properties/${id}/analytics/?days=${days}`);
    return response.json();
  }

  // Thermostats
  async getThermostats() {
    const response = await this.request('/thermostats/');
    return response.json();
  }

  async getThermostat(id) {
    const response = await this.request(`/thermostats/${id}/`);
    return response.json();
  }

  async createThermostat(data) {
    const response = await this.request('/thermostats/', {
      method: 'POST',
      body: JSON.stringify(data),
    });
    return response.json();
  }

  async updateThermostat(id, data) {
    const response = await this.request(`/thermostats/${id}/`, {
      method: 'PATCH',
      body: JSON.stringify(data),
    });
    return response.json();
  }

  async controlThermostat(id, action, params) {
    const response = await this.request(`/thermostats/${id}/control/`, {
      method: 'POST',
      body: JSON.stringify({ action, ...params }),
    });
    return response.json();
  }

  async syncThermostat(id) {
    const response = await this.request(`/thermostats/${id}/sync/`, {
      method: 'POST',
    });
    return response.json();
  }

  // Schedules
  async getSchedules() {
    const response = await this.request('/schedules/');
    return response.json();
  }

  async createSchedule(data) {
    const response = await this.request('/schedules/', {
      method: 'POST',
      body: JSON.stringify(data),
    });
    return response.json();
  }

  async updateSchedule(id, data) {
    const response = await this.request(`/schedules/${id}/`, {
      method: 'PATCH',
      body: JSON.stringify(data),
    });
    return response.json();
  }

  async deleteSchedule(id) {
    const response = await this.request(`/schedules/${id}/`, {
      method: 'DELETE',
    });
    return response.ok;
  }

  // Alerts
  async getAlerts() {
    const response = await this.request('/alerts/');
    return response.json();
  }

  async acknowledgeAlert(id) {
    const response = await this.request(`/alerts/${id}/acknowledge/`, {
      method: 'POST',
    });
    return response.json();
  }

  // Dashboard
  async getDashboard() {
    const response = await this.request('/dashboard/');
    return response.json();
  }
}

export const apiClient = new ApiClient();

