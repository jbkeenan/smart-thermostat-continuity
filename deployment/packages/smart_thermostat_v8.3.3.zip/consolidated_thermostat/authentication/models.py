from django.db import models
from django.contrib.auth.models import AbstractUser


class User(AbstractUser):
    """
    Custom user model extending Django's AbstractUser
    """
    phone_number = models.CharField(max_length=20, blank=True, null=True)
    preferred_temperature_unit = models.CharField(
        max_length=1,
        choices=[('F', 'Fahrenheit'), ('C', 'Celsius')],
        default='F'
    )
    
    class Meta:
        verbose_name = 'User'
        verbose_name_plural = 'Users'
    
    def __str__(self):
        return f"{self.first_name} {self.last_name} ({self.email})"
    
    @property
    def full_name(self):
        return f"{self.first_name} {self.last_name}".strip()

