from django.db import models
from django.conf import settings


class Thermostat(models.Model):
    """
    Model for thermostats that belong to properties.
    Property-centric architecture: thermostats belong to properties.
    """
    THERMOSTAT_BRANDS = [
        ('nest', 'Google Nest'),
        ('cielo', 'Cielo'),
        ('pioneer', 'Pioneer'),
        ('honeywell', 'Honeywell'),
        ('ecobee', 'Ecobee'),
        ('other', 'Other'),
    ]
    
    THERMOSTAT_MODES = [
        ('heat', 'Heat'),
        ('cool', 'Cool'),
        ('auto', 'Auto'),
        ('off', 'Off'),
        ('eco', 'Eco'),
    ]
    
    FAN_MODES = [
        ('auto', 'Auto'),
        ('on', 'On'),
        ('circulate', 'Circulate'),
    ]
    
    # Basic information
    name = models.CharField(max_length=100)
    property_ref = models.ForeignKey(
        'properties.Property', 
        on_delete=models.CASCADE, 
        related_name='thermostats'
    )
    
    # Device information
    brand = models.CharField(max_length=20, choices=THERMOSTAT_BRANDS)
    model = models.CharField(max_length=100)
    device_id = models.CharField(max_length=255, unique=True)
    firmware_version = models.CharField(max_length=50, blank=True, null=True)
    
    # Location within property
    location = models.CharField(
        max_length=100, 
        help_text="Location within the property (e.g., 'Living Room', 'Master Bedroom')"
    )
    zone = models.CharField(
        max_length=50, 
        blank=True, 
        null=True,
        help_text="HVAC zone if applicable"
    )
    
    # Current status
    current_temperature = models.DecimalField(
        max_digits=4, 
        decimal_places=1, 
        null=True, 
        blank=True
    )
    target_temperature = models.DecimalField(
        max_digits=4, 
        decimal_places=1, 
        null=True, 
        blank=True
    )
    current_humidity = models.PositiveSmallIntegerField(null=True, blank=True)
    mode = models.CharField(max_length=10, choices=THERMOSTAT_MODES, default='off')
    fan_mode = models.CharField(max_length=10, choices=FAN_MODES, default='auto')
    
    # System status
    is_online = models.BooleanField(default=True)
    is_heating = models.BooleanField(default=False)
    is_cooling = models.BooleanField(default=False)
    last_seen = models.DateTimeField(null=True, blank=True)
    
    # API credentials and configuration
    api_key = models.CharField(max_length=255, blank=True, null=True)
    api_token = models.CharField(max_length=255, blank=True, null=True)
    api_refresh_token = models.CharField(max_length=255, blank=True, null=True)
    api_config = models.JSONField(
        default=dict,
        help_text="Additional API configuration specific to the thermostat brand"
    )
    
    # Settings
    is_active = models.BooleanField(default=True)
    follows_property_schedule = models.BooleanField(
        default=True,
        help_text="Whether this thermostat follows the property-wide schedule"
    )
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = 'Thermostat'
        verbose_name_plural = 'Thermostats'
        ordering = ['property_ref', 'location', 'name']
    
    def __str__(self):
        return f"{self.property_ref.name} - {self.location} ({self.name})"
    
    @property
    def display_name(self):
        """Return a user-friendly display name"""
        if self.location:
            return f"{self.location} - {self.name}"
        return self.name
    
    @property
    def is_connected(self):
        """Check if thermostat is currently connected and responsive"""
        if not self.is_online:
            return False
        
        if self.last_seen:
            from django.utils import timezone
            from datetime import timedelta
            # Consider offline if not seen in last 10 minutes
            return timezone.now() - self.last_seen < timedelta(minutes=10)
        
        return True


class ThermostatCommand(models.Model):
    """
    Model for tracking commands sent to thermostats.
    """
    COMMAND_TYPES = [
        ('set_temperature', 'Set Temperature'),
        ('set_mode', 'Set Mode'),
        ('set_fan_mode', 'Set Fan Mode'),
        ('set_schedule', 'Set Schedule'),
        ('sync_status', 'Sync Status'),
        ('reboot', 'Reboot'),
        ('other', 'Other'),
    ]
    
    COMMAND_STATUS = [
        ('pending', 'Pending'),
        ('sent', 'Sent'),
        ('success', 'Success'),
        ('failed', 'Failed'),
        ('timeout', 'Timeout'),
    ]
    
    thermostat = models.ForeignKey(
        Thermostat, 
        on_delete=models.CASCADE, 
        related_name='commands'
    )
    command_type = models.CharField(max_length=20, choices=COMMAND_TYPES)
    parameters = models.JSONField(default=dict)
    status = models.CharField(max_length=10, choices=COMMAND_STATUS, default='pending')
    result = models.JSONField(null=True, blank=True)
    error_message = models.TextField(blank=True, null=True)
    
    # Timing
    created_at = models.DateTimeField(auto_now_add=True)
    sent_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    
    # Metadata
    initiated_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='thermostat_commands'
    )
    source = models.CharField(
        max_length=50,
        choices=[
            ('manual', 'Manual'),
            ('schedule', 'Schedule'),
            ('automation', 'Automation'),
            ('api', 'API'),
        ],
        default='manual'
    )
    
    class Meta:
        verbose_name = 'Thermostat Command'
        verbose_name_plural = 'Thermostat Commands'
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.get_command_type_display()} to {self.thermostat.display_name}"


class ThermostatReading(models.Model):
    """
    Model for storing historical thermostat readings and sensor data.
    """
    thermostat = models.ForeignKey(
        Thermostat,
        on_delete=models.CASCADE,
        related_name='readings'
    )
    
    # Sensor readings
    temperature = models.DecimalField(max_digits=4, decimal_places=1)
    humidity = models.PositiveSmallIntegerField(null=True, blank=True)
    target_temperature = models.DecimalField(max_digits=4, decimal_places=1)
    
    # System state
    mode = models.CharField(max_length=10, choices=Thermostat.THERMOSTAT_MODES)
    fan_mode = models.CharField(max_length=10, choices=Thermostat.FAN_MODES)
    is_heating = models.BooleanField(default=False)
    is_cooling = models.BooleanField(default=False)
    
    # Additional data
    outside_temperature = models.DecimalField(
        max_digits=4, 
        decimal_places=1, 
        null=True, 
        blank=True
    )
    energy_usage = models.DecimalField(
        max_digits=8, 
        decimal_places=3, 
        null=True, 
        blank=True,
        help_text="Energy usage in kWh for this reading period"
    )
    
    # Timing
    timestamp = models.DateTimeField()
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name = 'Thermostat Reading'
        verbose_name_plural = 'Thermostat Readings'
        ordering = ['-timestamp']
        indexes = [
            models.Index(fields=['thermostat', '-timestamp']),
            models.Index(fields=['timestamp']),
        ]
    
    def __str__(self):
        return f"{self.thermostat.display_name} - {self.timestamp.strftime('%Y-%m-%d %H:%M')}"


class ThermostatAlert(models.Model):
    """
    Model for thermostat-related alerts and notifications.
    """
    ALERT_TYPES = [
        ('offline', 'Device Offline'),
        ('temperature_extreme', 'Extreme Temperature'),
        ('humidity_extreme', 'Extreme Humidity'),
        ('energy_spike', 'Energy Usage Spike'),
        ('maintenance_due', 'Maintenance Due'),
        ('filter_change', 'Filter Change Required'),
        ('system_error', 'System Error'),
        ('other', 'Other'),
    ]
    
    SEVERITY_LEVELS = [
        ('low', 'Low'),
        ('medium', 'Medium'),
        ('high', 'High'),
        ('critical', 'Critical'),
    ]
    
    thermostat = models.ForeignKey(
        Thermostat,
        on_delete=models.CASCADE,
        related_name='alerts'
    )
    
    alert_type = models.CharField(max_length=20, choices=ALERT_TYPES)
    severity = models.CharField(max_length=10, choices=SEVERITY_LEVELS)
    title = models.CharField(max_length=255)
    message = models.TextField()
    
    # Status
    is_active = models.BooleanField(default=True)
    is_acknowledged = models.BooleanField(default=False)
    acknowledged_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='acknowledged_alerts'
    )
    acknowledged_at = models.DateTimeField(null=True, blank=True)
    
    # Additional data
    data = models.JSONField(default=dict)
    
    # Timing
    created_at = models.DateTimeField(auto_now_add=True)
    resolved_at = models.DateTimeField(null=True, blank=True)
    
    class Meta:
        verbose_name = 'Thermostat Alert'
        verbose_name_plural = 'Thermostat Alerts'
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.title} - {self.thermostat.display_name}"

