from django.db import models
from django.conf import settings


class Property(models.Model):
    """
    Model for properties that contain thermostats and schedules.
    This is the central model in our property-centric architecture.
    """
    PROPERTY_TYPES = [
        ('residential', 'Residential'),
        ('commercial', 'Commercial'),
        ('vacation_rental', 'Vacation Rental'),
        ('office', 'Office'),
        ('retail', 'Retail'),
        ('other', 'Other'),
    ]
    
    # Basic information
    name = models.CharField(max_length=200)
    address = models.TextField()
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='properties'
    )
    
    # Property details
    property_type = models.CharField(
        max_length=20,
        choices=PROPERTY_TYPES,
        default='residential'
    )
    square_footage = models.PositiveIntegerField(null=True, blank=True)
    num_bedrooms = models.PositiveSmallIntegerField(null=True, blank=True)
    num_bathrooms = models.PositiveSmallIntegerField(null=True, blank=True)
    
    # Settings
    timezone = models.CharField(max_length=50, default='UTC')
    is_active = models.BooleanField(default=True)
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = 'Property'
        verbose_name_plural = 'Properties'
        ordering = ['name']
    
    def __str__(self):
        return self.name
    
    @property
    def thermostat_count(self):
        """Return the number of thermostats in this property"""
        return self.thermostats.count()
    
    @property
    def active_schedules_count(self):
        """Return the number of active schedules for this property"""
        return self.schedules.filter(is_active=True).count()


class PropertySettings(models.Model):
    """
    Settings and preferences for a property
    """
    property_ref = models.OneToOneField(
        Property,
        on_delete=models.CASCADE,
        related_name='settings'
    )
    
    # Temperature settings
    default_temperature = models.DecimalField(
        max_digits=4,
        decimal_places=1,
        default=72.0,
        help_text="Default temperature in Fahrenheit"
    )
    away_temperature = models.DecimalField(
        max_digits=4,
        decimal_places=1,
        default=65.0,
        help_text="Temperature when property is unoccupied"
    )
    sleep_temperature = models.DecimalField(
        max_digits=4,
        decimal_places=1,
        default=68.0,
        help_text="Temperature during sleep hours"
    )
    min_temperature = models.DecimalField(
        max_digits=4,
        decimal_places=1,
        default=60.0,
        help_text="Minimum allowed temperature"
    )
    max_temperature = models.DecimalField(
        max_digits=4,
        decimal_places=1,
        default=85.0,
        help_text="Maximum allowed temperature"
    )
    
    # Energy and automation settings
    energy_saving_mode = models.BooleanField(
        default=True,
        help_text="Enable energy-saving optimizations"
    )
    schedule_enabled = models.BooleanField(
        default=True,
        help_text="Enable automatic scheduling"
    )
    auto_away_enabled = models.BooleanField(
        default=False,
        help_text="Automatically detect when property is unoccupied"
    )
    
    # Calendar integration settings
    calendar_integration_enabled = models.BooleanField(
        default=False,
        help_text="Enable calendar-based scheduling"
    )
    booking_platform = models.CharField(
        max_length=50,
        choices=[
            ('airbnb', 'Airbnb'),
            ('vrbo', 'VRBO'),
            ('booking', 'Booking.com'),
            ('manual', 'Manual Entry'),
            ('other', 'Other'),
        ],
        blank=True,
        null=True
    )
    pre_arrival_hours = models.PositiveSmallIntegerField(
        default=2,
        help_text="Hours before guest arrival to prepare property"
    )
    post_departure_hours = models.PositiveSmallIntegerField(
        default=1,
        help_text="Hours after guest departure to return to away mode"
    )
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = 'Property Settings'
        verbose_name_plural = 'Property Settings'
    
    def __str__(self):
        return f"Settings for {self.property_ref.name}"


class PropertySchedule(models.Model):
    """
    Schedules for properties (tied to properties, not individual thermostats)
    """
    SCHEDULE_TYPES = [
        ('heating', 'Heating'),
        ('cooling', 'Cooling'),
        ('away', 'Away'),
        ('sleep', 'Sleep'),
        ('guest_arrival', 'Guest Arrival'),
        ('guest_departure', 'Guest Departure'),
        ('custom', 'Custom'),
    ]
    
    RECURRENCE_PATTERNS = [
        ('none', 'No Recurrence'),
        ('daily', 'Daily'),
        ('weekly', 'Weekly'),
        ('monthly', 'Monthly'),
        ('weekdays', 'Weekdays Only'),
        ('weekends', 'Weekends Only'),
        ('custom', 'Custom Days'),
    ]
    
    PRIORITY_LEVELS = [
        (1, 'Low'),
        (2, 'Normal'),
        (3, 'High'),
        (4, 'Critical'),
    ]
    
    # Basic information
    property_ref = models.ForeignKey(
        Property,
        on_delete=models.CASCADE,
        related_name='schedules'
    )
    name = models.CharField(max_length=200)
    description = models.TextField(blank=True, null=True)
    schedule_type = models.CharField(max_length=20, choices=SCHEDULE_TYPES)
    priority = models.PositiveSmallIntegerField(choices=PRIORITY_LEVELS, default=2)
    
    # Schedule timing
    start_date = models.DateField()
    end_date = models.DateField(null=True, blank=True)
    start_time = models.TimeField()
    end_time = models.TimeField(null=True, blank=True)
    
    # Recurrence settings
    is_recurring = models.BooleanField(default=False)
    recurrence_pattern = models.CharField(
        max_length=10,
        choices=RECURRENCE_PATTERNS,
        default='none'
    )
    
    # Days of week (for custom recurrence)
    monday = models.BooleanField(default=False)
    tuesday = models.BooleanField(default=False)
    wednesday = models.BooleanField(default=False)
    thursday = models.BooleanField(default=False)
    friday = models.BooleanField(default=False)
    saturday = models.BooleanField(default=False)
    sunday = models.BooleanField(default=False)
    
    # Temperature setting
    target_temperature = models.DecimalField(max_digits=4, decimal_places=1)
    
    # Booking information (for vacation rentals)
    booking_id = models.CharField(max_length=100, blank=True, null=True)
    guest_name = models.CharField(max_length=200, blank=True, null=True)
    
    # Status
    is_active = models.BooleanField(default=True)
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = 'Property Schedule'
        verbose_name_plural = 'Property Schedules'
        ordering = ['-priority', 'start_date', 'start_time']
    
    def __str__(self):
        return f"{self.property_ref.name} - {self.name}"
    
    @property
    def is_currently_active(self):
        """Check if this schedule is currently active"""
        from django.utils import timezone
        now = timezone.now()
        
        # Check if we're within the date range
        if self.start_date > now.date():
            return False
        
        if self.end_date and self.end_date < now.date():
            return False
        
        # Check if we're within the time range (simplified)
        current_time = now.time()
        if self.end_time:
            return self.start_time <= current_time <= self.end_time
        
        return True


class PropertyEnergyData(models.Model):
    """
    Energy consumption and cost data for properties
    """
    property_ref = models.ForeignKey(
        Property,
        on_delete=models.CASCADE,
        related_name='energy_data'
    )
    
    # Time period
    date = models.DateField()
    hour = models.PositiveSmallIntegerField(
        null=True,
        blank=True,
        help_text="Hour of day (0-23) for hourly data"
    )
    
    # Energy metrics
    energy_consumed = models.DecimalField(
        max_digits=10,
        decimal_places=3,
        help_text="Energy consumed in kWh"
    )
    cost = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        help_text="Cost in dollars"
    )
    hvac_runtime_minutes = models.PositiveIntegerField(
        null=True,
        blank=True,
        help_text="HVAC system runtime in minutes"
    )
    
    # Environmental data
    outside_temperature = models.DecimalField(
        max_digits=4,
        decimal_places=1,
        null=True,
        blank=True
    )
    humidity = models.PositiveSmallIntegerField(null=True, blank=True)
    average_indoor_temperature = models.DecimalField(
        max_digits=4,
        decimal_places=1,
        null=True,
        blank=True
    )
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name = 'Property Energy Data'
        verbose_name_plural = 'Property Energy Data'
        ordering = ['-date', '-hour']
        indexes = [
            models.Index(fields=['property_ref', '-date']),
            models.Index(fields=['date']),
        ]
    
    def __str__(self):
        hour_str = f" {self.hour}:00" if self.hour is not None else ""
        return f"{self.property_ref.name} - {self.date}{hour_str}"

