"""
Initialize file for the authentication app
"""

default_app_config = 'authentication.apps.AuthenticationConfig'
